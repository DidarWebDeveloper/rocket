<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Github */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="github-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'login')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'node_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'avatar_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gravatar_id')->textInput() ?>

    <?= $form->field($model, 'url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'html_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'followers_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'following_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gists_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'starred_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'subscriptions_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'organizations_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'repos_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'events_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'received_events_url')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'type')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'site_admin')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'company')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'blog')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'location')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'hireable')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'bio')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'public_repos')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'public_gists')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'followers')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'following')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'created_at')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'updated_at')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
