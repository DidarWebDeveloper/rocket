<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Github */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Githubs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="github-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'login',
            'node_id',
            'avatar_url:url',
            'gravatar_id',
            'url:url',
            'html_url:url',
            'followers_url:url',
            'following_url:url',
            'gists_url:url',
            'starred_url:url',
            'subscriptions_url:url',
            'organizations_url:url',
            'repos_url:url',
            'events_url:url',
            'received_events_url:url',
            'type',
            'site_admin',
            'name',
            'company',
            'blog',
            'location',
            'email:email',
            'hireable',
            'bio',
            'public_repos',
            'public_gists',
            'followers',
            'following',
            'created_at',
            'updated_at',
        ],
    ]) ?>

</div>
