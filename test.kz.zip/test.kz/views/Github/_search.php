<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\GithubSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="github-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'login') ?>

    <?= $form->field($model, 'node_id') ?>

    <?= $form->field($model, 'avatar_url') ?>

    <?= $form->field($model, 'gravatar_id') ?>

    <?php // echo $form->field($model, 'url') ?>

    <?php // echo $form->field($model, 'html_url') ?>

    <?php // echo $form->field($model, 'followers_url') ?>

    <?php // echo $form->field($model, 'following_url') ?>

    <?php // echo $form->field($model, 'gists_url') ?>

    <?php // echo $form->field($model, 'starred_url') ?>

    <?php // echo $form->field($model, 'subscriptions_url') ?>

    <?php // echo $form->field($model, 'organizations_url') ?>

    <?php // echo $form->field($model, 'repos_url') ?>

    <?php // echo $form->field($model, 'events_url') ?>

    <?php // echo $form->field($model, 'received_events_url') ?>

    <?php // echo $form->field($model, 'type') ?>

    <?php // echo $form->field($model, 'site_admin') ?>

    <?php // echo $form->field($model, 'name') ?>

    <?php // echo $form->field($model, 'company') ?>

    <?php // echo $form->field($model, 'blog') ?>

    <?php // echo $form->field($model, 'location') ?>

    <?php // echo $form->field($model, 'email') ?>

    <?php // echo $form->field($model, 'hireable') ?>

    <?php // echo $form->field($model, 'bio') ?>

    <?php // echo $form->field($model, 'public_repos') ?>

    <?php // echo $form->field($model, 'public_gists') ?>

    <?php // echo $form->field($model, 'followers') ?>

    <?php // echo $form->field($model, 'following') ?>

    <?php // echo $form->field($model, 'created_at') ?>

    <?php // echo $form->field($model, 'updated_at') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
