<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\GithubSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Githubs';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="github-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <form action="/web/github/automatical" method="get">
        <div class="form-group">
            <label for="email">Ведите имя пользователя на Github</label>
            <input type="text" class="form-control" id="login" name="login">
        </div>

        <button type="submit" class="btn btn-success">Добавить</button>
    </form>
    <!-- form -->
    <?php  //echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'login',
            'node_id',
            'avatar_url:url',
            'gravatar_id',
            //'url:url',
            //'html_url:url',
            //'followers_url:url',
            //'following_url:url',
            //'gists_url:url',
            //'starred_url:url',
            //'subscriptions_url:url',
            //'organizations_url:url',
            //'repos_url:url',
            //'events_url:url',
            //'received_events_url:url',
            //'type',
            //'site_admin',
            //'name',
            //'company',
            //'blog',
            //'location',
            //'email:email',
            //'hireable',
            //'bio',
            //'public_repos',
            //'public_gists',
            //'followers',
            //'following',
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
