<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "github".
 *
 * @property string $id
 * @property string $login
 * @property string $node_id
 * @property string $avatar_url
 * @property int $gravatar_id
 * @property string $url
 * @property string $html_url
 * @property string $followers_url
 * @property string $following_url
 * @property string $gists_url
 * @property string $starred_url
 * @property string $subscriptions_url
 * @property string $organizations_url
 * @property string $repos_url
 * @property string $events_url
 * @property string $received_events_url
 * @property string $type
 * @property string $site_admin
 * @property string $name
 * @property string $company
 * @property string $blog
 * @property string $location
 * @property string $email
 * @property string $hireable
 * @property string $bio
 * @property string $public_repos
 * @property string $public_gists
 * @property string $followers
 * @property string $following
 * @property string $created_at
 * @property string $updated_at
 */
class Github extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'github';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['login', 'node_id', 'avatar_url', 'gravatar_id', 'url', 'html_url', 'followers_url', 'following_url', 'gists_url', 'starred_url', 'subscriptions_url', 'organizations_url', 'repos_url', 'events_url', 'received_events_url', 'type', 'site_admin', 'name', 'company', 'blog', 'location', 'email', 'hireable', 'bio', 'public_repos', 'public_gists', 'followers', 'following', 'created_at', 'updated_at'], 'default', 'value' => null],
            [['gravatar_id'], 'integer'],
            [['login', 'node_id', 'url', 'html_url', 'followers_url', 'following_url', 'gists_url', 'starred_url', 'subscriptions_url', 'organizations_url', 'repos_url', 'events_url', 'received_events_url', 'type', 'site_admin', 'name', 'company', 'blog', 'location', 'email', 'hireable', 'bio', 'public_repos', 'public_gists', 'followers', 'following', 'created_at', 'updated_at'], 'string', 'max' => 255],
            [['avatar_url'], 'string', 'max' => 512],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'login' => 'Login',
            'node_id' => 'Node ID',
            'avatar_url' => 'Avatar Url',
            'gravatar_id' => 'Gravatar ID',
            'url' => 'Url',
            'html_url' => 'Html Url',
            'followers_url' => 'Followers Url',
            'following_url' => 'Following Url',
            'gists_url' => 'Gists Url',
            'starred_url' => 'Starred Url',
            'subscriptions_url' => 'Subscriptions Url',
            'organizations_url' => 'Organizations Url',
            'repos_url' => 'Repos Url',
            'events_url' => 'Events Url',
            'received_events_url' => 'Received Events Url',
            'type' => 'Type',
            'site_admin' => 'Site Admin',
            'name' => 'Name',
            'company' => 'Company',
            'blog' => 'Blog',
            'location' => 'Location',
            'email' => 'Email',
            'hireable' => 'Hireable',
            'bio' => 'Bio',
            'public_repos' => 'Public Repos',
            'public_gists' => 'Public Gists',
            'followers' => 'Followers',
            'following' => 'Following',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
