<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Github;

/**
 * GithubSearch represents the model behind the search form of `app\models\Github`.
 */
class GithubSearch extends Github
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'gravatar_id'], 'integer'],
            [['login', 'node_id', 'avatar_url', 'url', 'html_url', 'followers_url', 'following_url', 'gists_url', 'starred_url', 'subscriptions_url', 'organizations_url', 'repos_url', 'events_url', 'received_events_url', 'type', 'site_admin', 'name', 'company', 'blog', 'location', 'email', 'hireable', 'bio', 'public_repos', 'public_gists', 'followers', 'following', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Github::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'gravatar_id' => $this->gravatar_id,
        ]);

        $query->andFilterWhere(['like', 'login', $this->login])
            ->andFilterWhere(['like', 'node_id', $this->node_id])
            ->andFilterWhere(['like', 'avatar_url', $this->avatar_url])
            ->andFilterWhere(['like', 'url', $this->url])
            ->andFilterWhere(['like', 'html_url', $this->html_url])
            ->andFilterWhere(['like', 'followers_url', $this->followers_url])
            ->andFilterWhere(['like', 'following_url', $this->following_url])
            ->andFilterWhere(['like', 'gists_url', $this->gists_url])
            ->andFilterWhere(['like', 'starred_url', $this->starred_url])
            ->andFilterWhere(['like', 'subscriptions_url', $this->subscriptions_url])
            ->andFilterWhere(['like', 'organizations_url', $this->organizations_url])
            ->andFilterWhere(['like', 'repos_url', $this->repos_url])
            ->andFilterWhere(['like', 'events_url', $this->events_url])
            ->andFilterWhere(['like', 'received_events_url', $this->received_events_url])
            ->andFilterWhere(['like', 'type', $this->type])
            ->andFilterWhere(['like', 'site_admin', $this->site_admin])
            ->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['like', 'company', $this->company])
            ->andFilterWhere(['like', 'blog', $this->blog])
            ->andFilterWhere(['like', 'location', $this->location])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'hireable', $this->hireable])
            ->andFilterWhere(['like', 'bio', $this->bio])
            ->andFilterWhere(['like', 'public_repos', $this->public_repos])
            ->andFilterWhere(['like', 'public_gists', $this->public_gists])
            ->andFilterWhere(['like', 'followers', $this->followers])
            ->andFilterWhere(['like', 'following', $this->following])
            ->andFilterWhere(['like', 'created_at', $this->created_at])
            ->andFilterWhere(['like', 'updated_at', $this->updated_at]);

        return $dataProvider;
    }
}
