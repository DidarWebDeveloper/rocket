<?php

namespace app\controllers;

use Yii;
use app\models\Github;
use app\models\GithubSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * GithubController implements the CRUD actions for Github model.
 */
class GithubController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Github models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new GithubSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Github model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Github model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Github();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Github model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
    /*****************************************/
    public function actionAutomatical()
    {
        $ch = curl_init();
        $username=$_GET['login'];
        $headers = [
            "username:DidarWebDeveloper",
            "Authorization: token b0de1b689a59f6452dea5c2d9fa461e941c786e7",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
            "Content-Type: text/plain",
            "Accept-Encoding: gzip, deflate",
            "Upgrade-Insecure-Requests: 1",
            "Host: api.github.com",
            "X-RateLimit-Limit:15555",
            "Cache-Control: max-age=0",
            "Connection: keep-alive",
            "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7,kk;q=0.6,nb;q=0.5"
        ];
        curl_setopt($ch, CURLOPT_URL, "https://api.github.com/users/".$username."/followers?client_id=5231729&client_secret=b0de1b689a59f6452dea5c2d9fa461e941c786e7");
        curl_setopt($ch, CURLOPT_HEADER, $headers);
        curl_setopt($ch, CURLOPT_USERAGENT, 'curl/7.48.0');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        //var_dump($headers);
        //$data=explode("[",curl_exec($ch));
        $data=stristr(curl_exec($ch),"{");
        $data=str_replace(']','',$data);
        $data = preg_replace('/\n$/','',$data);
        $data = json_decode("[".$data."]",true);

        curl_close($ch);
        //
       //print_r($data);
        //var_dump(json_decode("[".$data."]",true));
        foreach ($data as $dat_f){
            //echo $dat_f['login'].'<br>';
            $model = new Github();
            $model->login=$dat_f['login'];
            $model->node_id=$dat_f['node_id'];
            $model->avatar_url=$dat_f['avatar_url'];
            $model->gravatar_id=5;
            $model->url=$dat_f['url'];
            $model->html_url=$dat_f['html_url'];
            $model->followers_url=$dat_f['followers_url'];
            $model->following_url=$dat_f['following_url'];
            $model->gists_url=$dat_f['gists_url'];
            $model->starred_url=$dat_f['starred_url'];
            $model->subscriptions_url=$dat_f['subscriptions_url'];
            $model->organizations_url=$dat_f['organizations_url'];
            $model->repos_url=$dat_f['repos_url'];
            $model->events_url=$dat_f['events_url'];
            $model->received_events_url=$dat_f['received_events_url'];
            $model->type=$dat_f['type'];
            $model->site_admin=$dat_f['site_admin'];
            $model->name=$dat_f['name'];
            $model->company=$dat_f['company'];
            $model->blog=$dat_f['blog'];
            $model->location=$dat_f['location'];
            $model->email=$dat_f['email'];
            $model->hireable=$dat_f['hireable'];
            $model->bio=$dat_f['bio'];
            $model->public_repos=$dat_f['public_repos'];
            $model->public_gists=$dat_f['public_gists'];
            $model->followers=$dat_f['followers'];
            $model->following=$dat_f['following'];
            $model->created_at=$dat_f['created_at'];
            $model->updated_at=$dat_f['updated_at'];
            $model->insert(false);
            //die();
          //  print_r($model);
        }


        return $this->redirect(['/github']);
        //die();
        // завершение сеанса и освобождение ресурсов

      //  return $this->render('index',$git);
    }
    /**
     * Deletes an existing Github model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Github model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Github the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Github::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
